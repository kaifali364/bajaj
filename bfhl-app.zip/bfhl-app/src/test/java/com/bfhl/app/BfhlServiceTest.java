package com.bfhl.app;

import com.bfhl.app.dto.RequestDTO;
import com.bfhl.app.dto.ResponseDTO;
import com.bfhl.app.service.BfhlService;
import com.bfhl.app.service.impl.BfhlServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class BfhlServiceTest {

    private BfhlService bfhlService;

    @BeforeEach
    void setUp() {
        bfhlService = new BfhlServiceImpl();
    }

    // ------------------------------------------------------------------ //
    //  Basic response metadata
    // ------------------------------------------------------------------ //

    @Test
    @DisplayName("Response always contains correct user metadata")
    void testUserMetadata() {
        RequestDTO req = new RequestDTO(Collections.emptyList());
        ResponseDTO res = bfhlService.processData(req);

        assertTrue(res.isSuccess());
        assertEquals("mohammad_kaif_ali_06042004", res.getUserId());
        assertEquals("mohammadkaif230191@acropolis.in", res.getEmail());
        assertEquals("0827CI231083", res.getRollNumber());
    }

    // ------------------------------------------------------------------ //
    //  Number separation
    // ------------------------------------------------------------------ //

    @Test
    @DisplayName("Numbers are separated into odd and even correctly")
    void testOddEvenSeparation() {
        RequestDTO req = new RequestDTO(Arrays.asList("1", "2", "3", "4", "5"));
        ResponseDTO res = bfhlService.processData(req);

        assertEquals(List.of("1", "3", "5"), res.getOddNumbers());
        assertEquals(List.of("2", "4"), res.getEvenNumbers());
    }

    @Test
    @DisplayName("Numbers are kept as strings in the response")
    void testNumbersAsStrings() {
        RequestDTO req = new RequestDTO(Arrays.asList("10", "21"));
        ResponseDTO res = bfhlService.processData(req);

        assertTrue(res.getEvenNumbers().contains("10"));
        assertTrue(res.getOddNumbers().contains("21"));
    }

    // ------------------------------------------------------------------ //
    //  Alphabet handling
    // ------------------------------------------------------------------ //

    @Test
    @DisplayName("Alphabets are converted to uppercase")
    void testAlphabetsUppercase() {
        RequestDTO req = new RequestDTO(Arrays.asList("a", "b", "C"));
        ResponseDTO res = bfhlService.processData(req);

        assertEquals(List.of("A", "B", "C"), res.getAlphabets());
    }

    // ------------------------------------------------------------------ //
    //  Sum calculation
    // ------------------------------------------------------------------ //

    @Test
    @DisplayName("Sum of numeric values is correct and returned as string")
    void testSum() {
        RequestDTO req = new RequestDTO(Arrays.asList("1", "2", "3", "a"));
        ResponseDTO res = bfhlService.processData(req);

        assertEquals("6", res.getSum());
    }

    @Test
    @DisplayName("Sum is 0 when no numbers present")
    void testSumNoNumbers() {
        RequestDTO req = new RequestDTO(Arrays.asList("a", "b"));
        ResponseDTO res = bfhlService.processData(req);

        assertEquals("0", res.getSum());
    }

    // ------------------------------------------------------------------ //
    //  concat_string logic
    // ------------------------------------------------------------------ //

    @Test
    @DisplayName("concat_string: ayb → reversed bya → alternating caps ByA")
    void testConcatStringAyb() {
        // a y b  (each as separate items)
        RequestDTO req = new RequestDTO(Arrays.asList("a", "y", "b"));
        ResponseDTO res = bfhlService.processData(req);

        // concatenated → AYB, reversed → BYA, alternating → ByA
        assertEquals("ByA", res.getConcatString());
    }

    @Test
    @DisplayName("concat_string: AABCDDOE → reversed EODDCBAA → EoDdCbAa")
    void testConcatStringAABCDDOE() {
        RequestDTO req = new RequestDTO(Arrays.asList("A", "A", "B", "C", "D", "D", "O", "E"));
        ResponseDTO res = bfhlService.processData(req);

        assertEquals("EoDdCbAa", res.getConcatString());
    }

    @Test
    @DisplayName("concat_string is empty when no alphabets in input")
    void testConcatStringEmpty() {
        RequestDTO req = new RequestDTO(Arrays.asList("1", "2", "3"));
        ResponseDTO res = bfhlService.processData(req);

        assertEquals("", res.getConcatString());
    }

    // ------------------------------------------------------------------ //
    //  Special characters
    // ------------------------------------------------------------------ //

    @Test
    @DisplayName("Special characters are captured separately")
    void testSpecialCharacters() {
        RequestDTO req = new RequestDTO(Arrays.asList("@", "#", "1", "a"));
        ResponseDTO res = bfhlService.processData(req);

        assertTrue(res.getSpecialCharacters().contains("@"));
        assertTrue(res.getSpecialCharacters().contains("#"));
    }

    // ------------------------------------------------------------------ //
    //  Edge cases
    // ------------------------------------------------------------------ //

    @Test
    @DisplayName("Empty data list returns empty arrays and sum=0")
    void testEmptyData() {
        RequestDTO req = new RequestDTO(Collections.emptyList());
        ResponseDTO res = bfhlService.processData(req);

        assertTrue(res.isSuccess());
        assertTrue(res.getOddNumbers().isEmpty());
        assertTrue(res.getEvenNumbers().isEmpty());
        assertTrue(res.getAlphabets().isEmpty());
        assertTrue(res.getSpecialCharacters().isEmpty());
        assertEquals("0", res.getSum());
        assertEquals("", res.getConcatString());
    }

    @Test
    @DisplayName("Null data list is handled gracefully")
    void testNullData() {
        RequestDTO req = new RequestDTO(null);
        ResponseDTO res = bfhlService.processData(req);

        assertTrue(res.isSuccess());
        assertEquals("0", res.getSum());
    }

    @Test
    @DisplayName("Mixed input processes all categories correctly")
    void testMixedInput() {
        RequestDTO req = new RequestDTO(Arrays.asList("1", "2", "a", "B", "@", "5"));
        ResponseDTO res = bfhlService.processData(req);

        assertTrue(res.isSuccess());
        assertEquals(List.of("1", "5"), res.getOddNumbers());
        assertEquals(List.of("2"), res.getEvenNumbers());
        assertEquals(List.of("A", "B"), res.getAlphabets());
        assertEquals(List.of("@"), res.getSpecialCharacters());
        assertEquals("8", res.getSum());
    }
}
