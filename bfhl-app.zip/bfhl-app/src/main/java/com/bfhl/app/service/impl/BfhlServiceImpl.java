package com.bfhl.app.service.impl;

import com.bfhl.app.dto.RequestDTO;
import com.bfhl.app.dto.ResponseDTO;
import com.bfhl.app.service.BfhlService;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class BfhlServiceImpl implements BfhlService {

    private static final String USER_ID      = "mohammad_kaif_ali_06042004";
    private static final String EMAIL        = "mohammadkaif230191@acropolis.in";
    private static final String ROLL_NUMBER  = "0827CI231083";

    @Override
    public ResponseDTO processData(RequestDTO requestDTO) {
        List<String> data = requestDTO.getData();
        if (data == null) {
            data = new ArrayList<>();
        }

        List<String> oddNumbers       = new ArrayList<>();
        List<String> evenNumbers      = new ArrayList<>();
        List<String> alphabets        = new ArrayList<>();
        List<String> specialChars     = new ArrayList<>();
        long numericSum               = 0;
        StringBuilder alphabetBuilder = new StringBuilder();

        for (String item : data) {
            if (item == null || item.isEmpty()) continue;

            if (isNumeric(item)) {
                long val = Long.parseLong(item);
                numericSum += val;
                if (val % 2 == 0) {
                    evenNumbers.add(item);
                } else {
                    oddNumbers.add(item);
                }
            } else if (item.length() == 1 && Character.isLetter(item.charAt(0))) {
                String upper = item.toUpperCase();
                alphabets.add(upper);
                alphabetBuilder.append(upper);
            } else {
                // Special character(s) — keep as-is
                specialChars.add(item);
            }
        }

        String sum          = String.valueOf(numericSum);
        String concatString = buildConcatString(alphabetBuilder.toString());

        return ResponseDTO.builder()
                .isSuccess(true)
                .userId(USER_ID)
                .email(EMAIL)
                .rollNumber(ROLL_NUMBER)
                .oddNumbers(oddNumbers)
                .evenNumbers(evenNumbers)
                .alphabets(alphabets)
                .specialCharacters(specialChars)
                .sum(sum)
                .concatString(concatString)
                .build();
    }

    // ------------------------------------------------------------------ //
    //  Helpers
    // ------------------------------------------------------------------ //

    private boolean isNumeric(String s) {
        if (s == null || s.isEmpty()) return false;
        int start = 0;
        if (s.charAt(0) == '-') {
            if (s.length() == 1) return false;
            start = 1;
        }
        for (int i = start; i < s.length(); i++) {
            if (!Character.isDigit(s.charAt(i))) return false;
        }
        return true;
    }

    /**
     * Steps:
     *  1. Concatenate all alphabetical chars (already done in caller — passed as {@code alphabets})
     *  2. Reverse the result
     *  3. Apply alternating caps: index 0 → UPPER, index 1 → lower, index 2 → UPPER, …
     */
    private String buildConcatString(String alphabets) {
        if (alphabets == null || alphabets.isEmpty()) return "";

        // Step 1: already concatenated — reverse it
        String reversed = new StringBuilder(alphabets).reverse().toString();

        // Step 2: alternating caps (first char upper)
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < reversed.length(); i++) {
            char c = reversed.charAt(i);
            if (i % 2 == 0) {
                result.append(Character.toUpperCase(c));
            } else {
                result.append(Character.toLowerCase(c));
            }
        }
        return result.toString();
    }
}
