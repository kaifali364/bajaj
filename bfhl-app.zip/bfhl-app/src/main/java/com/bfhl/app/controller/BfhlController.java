package com.bfhl.app.controller;

import com.bfhl.app.dto.RequestDTO;
import com.bfhl.app.dto.ResponseDTO;
import com.bfhl.app.exception.BfhlException;
import com.bfhl.app.service.BfhlService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequestMapping("/bfhl")
@RequiredArgsConstructor
public class BfhlController {

    private final BfhlService bfhlService;

    @PostMapping
    public ResponseEntity<ResponseDTO> processData(@RequestBody RequestDTO requestDTO) {
        log.info("POST /bfhl received with data: {}", requestDTO);

        if (requestDTO == null) {
            throw new BfhlException("Request body must not be null");
        }

        ResponseDTO response = bfhlService.processData(requestDTO);
        return ResponseEntity.ok(response);
    }
}
