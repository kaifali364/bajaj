package com.bfhl.app.service;

import com.bfhl.app.dto.RequestDTO;
import com.bfhl.app.dto.ResponseDTO;

public interface BfhlService {

    ResponseDTO processData(RequestDTO requestDTO);
}
